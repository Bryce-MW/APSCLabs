package ca.thenetworknerds.APCS.lab13.vectorables;

public interface Vectorable {
    int getPrintHeight();
    int getPrintWidth();
}
