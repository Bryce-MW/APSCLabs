package ca.thenetworknerds.APCS.lab13.vectorables;

import ca.thenetworknerds.APCS.lab13.operations.HasFourFunctionCalculations;

public interface FourFunctionVectorable<T> extends Vectorable, HasFourFunctionCalculations<T> {
}
