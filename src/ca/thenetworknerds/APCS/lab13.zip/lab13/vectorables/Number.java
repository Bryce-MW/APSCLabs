package ca.thenetworknerds.APCS.lab13.vectorables;

public abstract class Number extends ExampleVector {}
