package ca.thenetworknerds.APCS.lab13.vectorables;

import ca.thenetworknerds.APCS.lab13.operations.Operable;

public abstract class ExampleVector implements Operable, Vectorable {
    public abstract ExampleVector createRandomValue();
}
