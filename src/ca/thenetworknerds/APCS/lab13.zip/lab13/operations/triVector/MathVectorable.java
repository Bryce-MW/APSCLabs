package ca.thenetworknerds.APCS.lab13.operations.triVector;

import ca.thenetworknerds.APCS.lab13.operations.*;

public interface MathVectorable<internalType> extends Operable {
    internalType squareDistance();
}
