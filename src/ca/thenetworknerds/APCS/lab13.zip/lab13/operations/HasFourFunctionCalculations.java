package ca.thenetworknerds.APCS.lab13.operations;

public interface HasFourFunctionCalculations<T> extends Addable<T>, Subtractable<T>, Multiplicable<T>, Dividable<T> {}
